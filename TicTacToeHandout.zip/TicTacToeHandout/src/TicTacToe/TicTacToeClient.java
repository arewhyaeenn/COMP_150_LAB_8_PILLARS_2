package TicTacToe;

/**
 * The Client will simply create a WindowManager.
 * The WindowManager serves as the entry point for
 * a TicTacToe game.
 */

public class TicTacToeClient
{
    public static void main(String[] args)
    {
        new WindowManager();
    }
}
