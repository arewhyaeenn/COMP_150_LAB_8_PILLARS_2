package TicTacToe;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


/**
 * The BoardButton class will run a single space in the
 * 3x3 TicTacToe board. When clicked, it will update itself
 * to have an X or O (depending on whose turn it is). It will
 * then set off a sequence of events in the BoardManager
 * which decides whether the game has and manages other gamestate
 * parameters (like whose turn it is).
 */

public class BoardButton extends JButton
{
    private final static String O_TEXT = "O";
    private final static String X_TEXT = "X";
    private final static String EMPTY_TEXT = " ";

    // The instance of BoardManager to which this button belongs
    private BoardManager boardManager;

    // The index of this button in the 3x3 board, from (0,0) to (3,3)
    // (0,0) is top left, (3,3) is bottom right
    private int xIndex, yIndex;

    // An enumerator listing all of the states that a spot
    // on a TicTacToe board can be in
    enum BUTTON_STATE
    {
        EMPTY,
        X,
        O,
        DISABLED
    }
    private BUTTON_STATE state;

    BoardButton(BoardManager boardManager, int x, int y)
    {
        super();

        this.boardManager = boardManager;
        this.xIndex = x;
        this.yIndex = y;

        this.setState(BUTTON_STATE.EMPTY);

        this.setupActionListeners();
        this.setupAesthetics(
                this.boardManager.getButtonWidth(),
                this.boardManager.getButtonHeight()
        );
    }


    /**
     * Links mouse clicks to the button's onClick function.
     */
    private void setupActionListeners()
    {
        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent event) {
                onClick(event);
            }
        });
    }


    /**
     * Defines what is done when the button is clicked.
     * Uses the event's getButton method to determine which mouse button was clicked.
     * If the button was the left click (MouseEvent.BUTTON1), calls the onLeftClick function
     * (unless control is held down, in which case onRightClick is called).
     * If the button was the right click (MouseEvent.BUTTON3), calls the onRightClick function.
     *
     * Check out the MouseEvent class; specifically, check out:
     * - MouseEvent.isControlDown
     * - MouseEvent.getButton
     *
     * @param event The MouseEvent which triggered the ActionListener.
     */
    private void onClick(MouseEvent event)
    {
        switch(event.getButton())
        {
            case MouseEvent.BUTTON1:
                if (event.isControlDown())
                    this.onRightClick();
                else
                    this.onLeftClick();
                break;
            case MouseEvent.BUTTON3:
                this.onRightClick();
                break;
            default:
                System.out.println("What button was that..." + event.getButton());
        }
    }


    /**
     * If the state variable is anything other than BUTTON_STATE.EMPTY,
     * does nothing.
     *
     * Otherwise, finds out which player's turn it is using the getTurn method
     * from the boardManager, and assigns this buttons state to a BUTTON_STATE
     * element (BUTTON_STATE.X or BUTTON_STATE.O) accordingly, by using the setState
     * method.
     */
    private void onLeftClick()
    {
        // TODO if this button is not in state BOARD_STATE.EMPTY, do nothing.
        // Otherwise, find out whose turn it is using the appropriate method
        // from the boardManager, and set this buttons state accordingly
        // using the appropriate BoardButton method.
    }


    /**
     * Does nothing. We only need 1 type of click to play TicTacToe.
     */
    private void onRightClick()
    {

    }


    /**
     * Sets the state instance variable to the value passed in as newState.
     * If this new state is anything other than BUTTON_STATE.DISABLED,
     * update the button's text to reflect the state (use the setText method).
     * If the new state is X or O, then a player has just made their move by
     * clicking this button; call the boardManager's endTurn method, and pass in
     * this BoardButton's xIndex and yIndex for the indices of the last move.
     *
     * @param newState the new state of the button, either an X or O for the player
     *                 that clicked this button, EMPTY for an unclicked button, or
     *                 DISABLED for a button which should no longer be clickable
     *                 because the game ended.
     */
    private void setState(BUTTON_STATE newState)
    {
        // TODO set this button's state to the appropriate new state

        // TODO if the new state is anything other than BUTTON_STATE.DISABLED,
        // update its text accordingly. See the X_TEXT, O_TEXT, and EMPTY_TEXT
        // variables defined at the top.
        // HINT: this button is a JButton. Find out how to change the text
        // on a JButton by googling or reading the JButton documentation.
    }


    /**
     * Accessor method to get the state of the button,
     * denoting which player (X or O) claimed this space
     * or EMPTY if neither play has claimed this space yet.
     * @return the state of this button
     */
    public BUTTON_STATE getState()
    {
        return this.state;
    }


    /**
     * Sets the buttons state to BUTTON_STATE.DISABLED so
     * the onClick functions do nothing.
     */
    @Override
    public void disable()
    {
        this.setState(BUTTON_STATE.DISABLED);
    }


    /* MUTATOR FOR INITIALIZING BUTTON SIZE, MARGINS, BORDER AND TEXT */

    /**
     * Sets up the button's aesthetic properties for a new game.
     * Sets the displayed size, the displayed text, the padding
     * inside the border, the type of border, etc...
     *
     * @param width width in pixels of the button
     * @param height height in pixels of the button
     */
    private void setupAesthetics(int width, int height)
    {
        this.setText(EMPTY_TEXT);
        this.setMargin(new Insets(0,0,0,0));
        this.setSize(new Dimension(width, height));
        this.setBorder(BorderFactory.createLineBorder(Color.black));
        this.setOpaque(true);
    }
}

