package TicTacToe;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

/**
 * The BoardManager class will manage the 3x3 grid of buttons necessary
 * for a TicTacToe game. It will also track which players turn it is,
 * and check after each turn if the game is over (and if so, who won).
 *
 * In other words, the BoardManager manages the game data itself.
 *
 * It will call methods from the StatusBar whenever changes in the gamestate
 * occur to ensure the StatusBar stays up to date.
 */

public class BoardManager extends JPanel
{
    private StatusBar statusBar;

    private BoardButton[][] buttons;
    private WindowManager windowManager;

    // width and height of board grid (number of buttons)
    final private int BOARD_WIDTH = 3;
    final private int BOARD_HEIGHT = 3;

    // width and height of buttons in pixels
    private static final int BUTTON_WIDTH = 100;
    private static final int BUTTON_HEIGHT = 100;

    // enumerator listing whose turn it might be
    // NONE is the value between games
    public enum TURN_STATE
    {
        X, O, NONE
    }

    // trackers for current players turn and number of turns passed in a game
    private TURN_STATE turn;
    private int turnCount;

    BoardManager(WindowManager windowManager)
    {
        super();
        this.windowManager = windowManager;
        this.setBackground(Color.GRAY);
    }

    /**
     * Sets all variables up for the start of a game as follows:
     * Sets the turnCount to 0.
     * Randomly chooses a starting player (sets turn to TURN_STATE.X or TURN_STATE.O).
     * Calls the statusBar's updateTurn method to reflect whose turn it is.
     * Calls the layoutButtons method to set up the 3x3 grid for a new game.
     */
    void initialize()
    {
        // TODO set the turnCount to 0

        // TODO set the turn to a random choice from X or O
        // (HINT: generate a random boolean)

        // TODO update the statusBar with whose turn it is
        // (see the StatusBar class to decide which method to call)

        // TODO reinitialize the buttons array with a new 3x3 grid of buttons
        // (don't use a loop, call the appropriate BoardManager method)
    }


    /**
     * Sets up the 3x3 grid of buttons for a new game as follows:
     *
     * DONE:
     * Removes all components from this object (note that BoardManager extends JPanel, check the JPanel documentation).
     * Sets this objects Layout to a new GridLayout with the necessary number of rows and columns.
     * Update this objects size.
     *
     * TODO:
     * Initializes the buttons array to be a 3x3 array of BoardButtons.
     *      (Don't use magic numbers, use BOARD_WIDTH and BOARD_HEIGHT instead of 3s)
     * Loops through the indexes in the buttons array (row by row) calling the addButton method at each x, y coordinate.
     *
     * DONE:
     * Revalidates and repaints this object.
     */
    private void layoutButtons()
    {
        this.removeAll();
        this.setLayout( new GridLayout(BOARD_HEIGHT, BOARD_WIDTH) );
        this.setSize(this.getPanelWidth(), this.getPanelHeight());

        // TODO your code goes here (see description above)
        // NOTE: order is important, go row by row, not column by column.

        // update the display
        this.revalidate();
        this.repaint();
    }

    void setStatusBar(StatusBar statusBar)
    {
        this.statusBar = statusBar;
    }


    /**
     * Creates a new BoardButton; passes in itself and the buttons x and y coordinates.
     * Adds the button to this JPanel's contents using the JPanel's add method.
     * Places a reference to the new BoardButton in the buttons array at the appropriate index.
     *
     * @param x the x coordinate of the new button
     * @param y the y coordinate of the new button
     */
    private void addButton(int x, int y)
    {
        // TODO complete this function
    }


    public TURN_STATE getTurn()
    {
        return this.turn;
    }


    /**
     * Checks if the last move caused someone to win the game.
     * If so, ends the game (with the player whose turn it currently is
     * as the winner. (Check out the endGame method).
     *
     * If nobody won the game, iterate the turnCount variable, then check
     * if the board is full by using the turnCount variable (there can
     * only be 9 turns in a game). If the game is over without a winner,
     * call the endGame method with TURN_STATE.NONE as an argument, to
     * end the game as a tie.
     *
     * If the game isn't over (i.e. the game didn't end above)
     * switch which players turn it is and call an appropriate method in
     * the statusBar to update it accordingly.
     *
     * @param x the x coordinate of the last move
     * @param y the y coordinate of the last move
     */
    public void endTurn(int x, int y)
    {
        if (checkForWinner(x, y))
        {
            // TODO end the game with the correct winner
            // (whoever's turn it is, they just won)
        }
        else
        {
            // TODO iterate the turn count

            if (this.turnCount > 8)
            {
                // TODO end the game with no winner (tie game)
            }
            else
            {
                // TODO switch whose turn it is, update the status bar
                // Check out the status bar class to determine which method to call
                // to update whose turn it displays
            }
        }
    }


    /**
     * Checks if there is a win involving the button at the specified
     * x and y indexes on the board.
     * @param xIndex
     * @param yIndex
     * @return true if someone won, false otherwise.
     */
    private boolean checkForWinner(int xIndex, int yIndex)
    {
        boolean winner = this.checkColumnForWinner(xIndex);
        if (!winner) winner = this.checkRowForWinner(yIndex);
        if (!winner) winner = this.checkDiagonalsForWinner(xIndex, yIndex);
        return winner;
    }


    /**
     * Checks if the column with the specified x index
     * contains either all X's or all O's to check if there
     * is a winner. Check out the BoardButton class's getState method.
     *
     * @param xIndex the xIndex of the row to be checked.
     * @return true if the column is all X's or all O's, false otherwise.
     */
    private boolean checkColumnForWinner(int xIndex)
    {
        // TODO check the column with the specified xIndex
        // if all 3 square are X's or all 3 squares are O's,
        // return true
        // otherwise, return false

        return true; // stub
    }


    /**
     * Checks if the row with the specified y index
     * contains either all X's or all O's to check if there
     * is a winner. Check out the BoardButton class's getState method.
     *
     * @param yIndex
     * @return true if the row is all X's or all O's, false otherwise.
     */
    private boolean checkRowForWinner(int yIndex)
    {
        // TODO check the row with the specified yIndex
        // if all 3 squares are X's or all 3 squares are O's,
        // return true
        // otherwise, return false

        return true; // stub
    }


    /**
     * If the specified x-y index is on the top-left to bottom-right
     * diagonal, checks if said diagonal is all X's or all O's and
     * returns true if it is.
     *
     * If the specified x-y index is on the top-right to bottom-left
     * diagonal, checks if said diagonal is all X's or all O's and
     * returns true if it is.
     *
     * Returns false if neither of the previous checks returned true.
     *
     * @param xIndex the x coordinate of the spot being checked for diagonal wins
     * @param yIndex the y coordinate of the spot being checked for diagonal wins
     * @return true if the button at the specified x-y index is part of
     * a win on a diagonal of the board, false otherwise.
     */
    private boolean checkDiagonalsForWinner(int xIndex, int yIndex)
    {
        // TODO if the specified x-y index is on the top-left to bottom-right
        // diagonal, check said diagonal to see if there is a winner.
        // if there is a winner, return true

        // TODO if the specified x-y index is on the top-right to bottom-left
        // diagonal, check said diagonal to see if there is a winner.
        // if there is a winner, return true

        // TODO if neither of the cases above returned true, there is no
        // winner on a diagonal; return false.

        return true; // stub
    }


    /**
     * Ends the game with the specified winner as follows:
     *
     * Disables all buttons with the disableButtons method.
     * If X or O won, increments the score with the statusBar's addPoint method.
     * Creates a message dialog stating that X won, O won or that there was a tie.
     * Calls the initialize method, to reset the board for the next game.
     *
     * @param winner the player that just won the game (NONE if it's a tie)
     */
    void endGame(TURN_STATE winner)
    {
        // TODO disable all of the buttons (don't loop through them, use the correct BoardManager method).

        // TODO create a popup dialog with a message saying "X WINS!", "O WINS!" or "TIE GAME!"
        // depending on the winner argument.

        // TODO start a new game (use a method from the windoeManager)
    }


    /**
     * Iterates through the buttons array, calling each BoardButton's disable method.
     * This method is for use at when a game ends, to disable all buttons until the
     * next game starts.
     */
    private void disableButtons()
    {
        // TODO loop through the buttons (in the array named "buttons")
        // (call each button's disable method)
    }


    /* ACCESSORS AND MUTATORS FOR SIZE */
    int getButtonWidth()
    {
        return BUTTON_WIDTH;
    }

    int getButtonHeight()
    {
        return BUTTON_HEIGHT;
    }

    int getPanelWidth()
    {
        return BUTTON_WIDTH * BOARD_WIDTH;
    }

    int getPanelHeight()
    {
        return BUTTON_HEIGHT * BOARD_HEIGHT;
    }

    void updateSize()
    {
        this.setSize(this.getPanelWidth(), this.getPanelHeight());
    }
}
