package GridLayoutDemo;

import javax.swing.*;
import java.awt.*;

public class DialogButton extends JButton
{
    private String message;

    public DialogButton(String textOnButton, String messageInDialog)
    {
        // construct JButton
        super(textOnButton);

        // store message in instance variable
        message = messageInDialog;

        // link up onClick function to button
        addActionListener(event->onClick());

        // aesthetics
        setBorder(BorderFactory.createLineBorder(Color.BLACK));
        setMargin(new Insets(0,0,0,0));
    }

    // function to run when clicked
    private void onClick()
    {
        JOptionPane.showMessageDialog(this, message);
    }
}
