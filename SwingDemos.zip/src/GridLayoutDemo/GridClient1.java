package GridLayoutDemo;

import ButtonDemo2.DialogButton;

import javax.swing.*;
import java.awt.*;

public class GridClient1
{
    public static final int NUMBER_OF_ROWS = 2;
    public static final int NUMBER_OF_COLS = 2;
    public static final int BUTTON_WIDTH = 75;
    public static final int BUTTON_HEIGHT = 100;

    public static void main(String[] args)
    {
        // set up frame
        JFrame frame = new JFrame();
        frame.setVisible(true);
        frame.setSize( NUMBER_OF_COLS * BUTTON_WIDTH, NUMBER_OF_ROWS * BUTTON_HEIGHT );
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        // set up buttons
        JButton helloButton = new DialogButton("Hello", "HELLO!");
        JButton goodbyeButton = new DialogButton("Goodbye", "GOODBYE!");
        JButton youWotButton = new DialogButton("Yew Wot?", "FIGHT ME YOU WONT!");
        JButton happyButton = new DialogButton("c:", "=D");


        Container contents = frame.getContentPane();

        /*
            The GridLayout allows elements to be added in a grid.
            It takes as input a number of rows, and a number of columns.
            The top-left element of the grid is at position (0,0).

            When elements are added to the grid, the are added in order
            from the top left, along each row, then into the next column.

            That is, elements are added at (0,0), then (0,1), then (0,2), ...
            until the first row is full, then at (1,0), then (1,1), and so on.

            Unless otherwise specified, all rows and columns will have the same
            width and height, and components added to them will fill them up entirely.

            Check out the GridLayout docs. If you want something more verstatile, check
            out the GridBagLayout docs instead!
         */
        contents.setLayout(new GridLayout(NUMBER_OF_ROWS, NUMBER_OF_COLS));

        // add buttons
        contents.add(helloButton);
        contents.add(goodbyeButton);
        contents.add(youWotButton);
        contents.add(happyButton);
    }
}
