package ButtonDemo1;

import javax.swing.*;
import java.awt.*;

public class ButtonDemo1
{
    public static void main(String[] args)
    {

        /*
            A JFrame is essentially a window which contains
            a Containter (java.awt.Container) to house the window's contents.

            Below we create a JFrame, make it visible, resize it, and lock its size.
            We also tell it what to do when the user hits the "x" button in the top left.
         */
        JFrame frame = new JFrame();
        frame.setVisible(true);
        frame.setSize(100, 100);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        /*
            The JFrame's getContentPane() method returns said Container.
            Generally this content pane isn't actually stored as a variable,
            and the JFrame's getter is called whenever the content pane needs
            to be referenced.
         */
        Container contents = frame.getContentPane();


        /*
            A JButton is... well... a button...
            Below a button is created, and the text displayed on the button is
            "Hello"
         */
        JButton button = new JButton("Hello");


        /*
            The line below tells the button what to do when it is pressed.
            The "event" is an ActionEvent. It houses some information about
            how the event (i.e. the user action) which activated the button.
            We'll talk more about ActionEvents later.

            This line essentially says to the button "when you are given some
            ActionEvent (referenced by name event, in this case), run the printHello
            method with the frame as an input. Check out the printHello method,
            defined after the main method.

            What should the button do when it is pressed?
         */
        button.addActionListener(event -> sayHello(button));


        /*
            The line below tells the content pane what layout to use to organize
            the positions of its inputs.

            We've chosen a BorderLayout, which allows content to be added to the sides
            (NORTH, SOUTH, EAST, WEST) of the content pane, the corners (NORTHWEST,
            SOUTHWEST, etc), and the center (CENTER).
         */
        contents.setLayout(new BorderLayout());


        /*
            The line below adds our button to the content pane, so it will be displayed
            in the window.
         */
        contents.add(button, BorderLayout.CENTER);
    }


    public static void sayHello(JButton button)
    {
        /*
            A message dialogue is essentially a popup window that displays
            a message and closes when the user hits an "OK" button on said
            popup window. It needs a parent component (in this case, the button)
            to display it, and a message to display.
         */
        JOptionPane.showMessageDialog(button, "HELLO!");
    }
}
