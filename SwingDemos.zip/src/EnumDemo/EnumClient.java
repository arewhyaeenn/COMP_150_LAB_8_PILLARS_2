package EnumDemo;

import javax.swing.*;
import java.awt.*;

public class EnumClient
{
    public static void main(String[] args)
    {
        JFrame frame = new JFrame();
        frame.setVisible(true);
        frame.setSize(100, 100);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton button = new MoodButton(100, 100);

        Container contents = frame.getContentPane();
        contents.setLayout(new BorderLayout());
        contents.add(button, BorderLayout.CENTER);
    }
}
