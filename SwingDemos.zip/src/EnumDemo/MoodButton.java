package EnumDemo;

import javax.swing.*;
import java.awt.*;

public class MoodButton extends JButton
{
    /*
        Here we make a new enum, called MOOD.
        Basically what this says is "There are exactly
        three moods, and they are HAPPY, MAD and ZEN."

        MOOD can now be used as a type, and any variable
        of type MOOD is has one of the three values HAPPY,
        MAD or ZEN.
     */

    enum MOOD
    {
        HAPPY,
        MAD,
        ZEN
    }

    // The below variable, named mood, is of type MOOD.
    // This means any values assigned to mood will be
    // HAPPY, MAD, or ZEN, as these are the only MOOD values.
    private MOOD mood;

    private final static String HAPPY_TEXT = "=D";
    private final static String MAD_TEXT = "xC";
    private final static String ZEN_TEXT = "B]";

    private final static Color HAPPY_COLOR = Color.YELLOW;
    private final static Color MAD_COLOR = Color.RED;
    private final static Color ZEN_COLOR = Color.CYAN;

    public MoodButton(int width, int height)
    {
        super();

        addActionListener(event->onClick());

        setBorder(BorderFactory.createLineBorder(Color.BLACK));
        setOpaque(true);
        setMargin(new Insets(0,0,0,0));
        setSize(new Dimension(width, height));
        revalidate();
        repaint();

        setMood(MOOD.HAPPY);
    }

    private void onClick()
    {
        rotateMood();
    }

    private void rotateMood()
    {
        switch(mood)
        {
            // We can write HAPPY instead of MOOD.HAPPY because mood is of type MOOD
            // In fact, we can't write MOOD.HAPPY, because this would be interpreted
            // as MOOD.MOOD.HAPPY
            case HAPPY:
                setMood(MOOD.MAD);
                break;
            case MAD:
                setMood(MOOD.ZEN);
                break;
            case ZEN:
                setMood(MOOD.HAPPY);
                break;
        }
    }

    private void setMood(MOOD newMood)
    {
        mood = newMood;
        switch(mood)
        {
            case HAPPY:
                setText(HAPPY_TEXT);
                setBackground(HAPPY_COLOR);
                break;
            case MAD:
                setText(MAD_TEXT);
                setBackground(MAD_COLOR);
                break;
            case ZEN:
                setText(ZEN_TEXT);
                setBackground(ZEN_COLOR);
                break;
        }
    }
}

