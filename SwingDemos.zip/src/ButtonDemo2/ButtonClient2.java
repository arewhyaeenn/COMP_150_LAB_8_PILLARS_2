package ButtonDemo2;

import javax.swing.*;
import java.awt.*;

public class ButtonClient2
{
    public static void main(String[] args)
    {
        // set up frame
        JFrame frame = new JFrame();
        frame.setVisible(true);
        frame.setSize(100, 100);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        /*
            This client is the same as the previous demo.
            We've compartmentalized better, and made a reusable "DialogButton"
            class to set up and run buttons
         */
        JButton button = new DialogButton("Hello", "HELLO!");


        // set up layout, add button
        Container contents = frame.getContentPane();
        contents.setLayout(new BorderLayout());
        contents.add(button, BorderLayout.CENTER);
    }
}
