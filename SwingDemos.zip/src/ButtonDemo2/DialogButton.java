package ButtonDemo2;

import javax.swing.*;
import java.awt.*;

public class DialogButton extends JButton
{
    private String message;

    public DialogButton(String textOnButton, String messageInDialog)
    {
        /*
            A DialogButton IS a JButton, with whatever extra functionality we add.
            The line below runs the constructor for the DialogButton's super class
            (which is the JButton class, because DialogButton extends JButton).

            So, the line below constructs a JButton, with the textOnButton string
            on the button itself.
         */
        super(textOnButton);


        /*
            Each DialogButton will have its own message to display in a dialog.
            That message will be stored in the instance variable "message".
            Below, we assign value to that field.
         */
        message = messageInDialog;


        /*
            Like the last demo, tell the button what to do.
            Notice we don't need to reference the button itself to add a
            listener, because "addActionListener" is a method of JButton and
            by extension it is also a method of DialogButton.

            The commented version with "this." before it is identical.
         */
        addActionListener(event->onClick());
        //this.addActionListener(event->onClick());


        /*
            The default border for JButtons is gross (on mac) and varies on different
            operating systems. Below, we change the border used by the button.
         */
        setBorder(BorderFactory.createLineBorder(Color.BLACK));


        /*
            Most swing elements have some default "Inset", which is the amount of
            padding inside the element which won't be occupied by contained elements
            (in this case, text).

            Sometimes, for aesthetic purposes, we will want to change how much padding
            is on the inside borders of an element. In this case, I want to remove all
            of the padding (so the contained text can go right up to the border,
            if necessary).

            The line below sets all of the padding to 0, so there is no space for padding
            on the inside of the button's border.
         */
        //setMargin(new Insets(0,0,0,0));
    }

    private void onClick()
    {
        JOptionPane.showMessageDialog(this, message);
    }
}
