package MineSweeper;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class BoardManager extends JPanel
{
    private WindowManager windowManager;
    private StatusBar statusBar;

    private DIFFICULTY difficulty;
    private BoardButton[][] buttons;

    // width and height of board grid (number of buttons)
    private int boardWidth;
    private int boardHeight;

    // parameters to track state of game
    private int mineCount;
    private int flagCount;
    private int safeCount;
    private boolean startOfGame;

    // width and height of buttons in pixels
    private static final int BUTTON_WIDTH = 30;
    private static final int BUTTON_HEIGHT = 30;

    public enum DIFFICULTY
    {
        BEGINNER, INTERMEDIATE, EXPERT
    }

    BoardManager(WindowManager windowManager)
    {
        super();

        this.windowManager = windowManager;

        setBackground(Color.GRAY);

        initializeBoard(DIFFICULTY.BEGINNER);
    }

    private void initializeBoard(DIFFICULTY difficulty)
    {
        setDifficulty(difficulty);
        resetGamestateParameters();
        layoutButtons();
        startOfGame = true;
    }

    public void initializeBoard()
    {
        initializeBoard(difficulty);
    }

    private void resetGamestateParameters()
    {
        flagCount = 0;
        Random generator = new Random();
        switch(difficulty)
        {
            case BEGINNER:
                boardWidth = generator.nextInt(3) + 8; // 8-10
                boardHeight = generator.nextInt(3) + 8;
                mineCount = 10;
                break;
            case INTERMEDIATE:
                boardWidth = generator.nextInt(3) + 13;
                boardHeight = generator.nextInt(3) + 13;
                mineCount = 40;
                break;
            case EXPERT:
                boardWidth = 30;
                boardHeight = 16;
                mineCount = 99;
                break;
        }
        safeCount = boardWidth * boardHeight;
    }

    private void layoutButtons()
    {
        removeAll();
        setLayout( new GridLayout(boardHeight, boardWidth) );
        setSize(getPanelWidth(), getPanelHeight());

        buttons = new BoardButton[boardWidth][boardHeight];
        for (int y = 0; y < boardHeight; y++)
        {
            for (int x = 0; x < boardWidth; x++)
            {
                addButton(x, y);
            }
        }

        revalidate();
        repaint();
    }

    void placeMines(int xSafe, int ySafe)
    {
        ArrayList<int[]> indexList = new ArrayList<>();
        for (int x = 0; x < boardWidth; x++)
        {
            for (int y = 0; y < boardHeight; y++)
            {
                int[] indexElement = {x, y};
                indexList.add( indexElement );
            }
        }

        Collections.shuffle(indexList);

        int count = 0;
        while (count < mineCount)
        {
            int[] index = indexList.remove(0);
            int x = index[0];
            int y = index[1];
            if (Math.abs(x-xSafe) > 1 || Math.abs(y-ySafe) > 1)
            {
                buttons[x][y].placeMine();
                safeCount--;
                count++;
            }
        }

        startOfGame = false;
    }

    void incrementAdjacentMines(int xIndex, int yIndex)
    {
        int xStart = Math.max(xIndex-1, 0);
        int xEnd = Math.min(xIndex+1, boardWidth-1);
        int yStart = Math.max(yIndex-1, 0);
        int yEnd = Math.min(yIndex+1, boardHeight-1);

        for (int x = xStart; x <= xEnd; x++)
        {
            for (int y = yStart; y <= yEnd; y++)
            {
                buttons[x][y].incrementAdjacentMines();
            }
        }
    }

    void clearAdjacent(int xIndex, int yIndex)
    {
        int xStart = Math.max(xIndex-1, 0);
        int xEnd = Math.min(xIndex+1, boardWidth-1);
        int yStart = Math.max(yIndex-1, 0);
        int yEnd = Math.min(yIndex+1, boardHeight-1);

        for (int x = xStart; x <= xEnd; x++)
        {
            for (int y = yStart; y <= yEnd; y++)
            {
                buttons[x][y].setClicked();
            }
        }
    }

    void setStatusBar(StatusBar statusBar)
    {
        this.statusBar = statusBar;
    }

    private void addButton(int x, int y)
    {
        BoardButton button = new BoardButton(this, x, y);
        add(button);
        this.buttons[x][y] = button;
    }

    private void disableButtons()
    {
        for (int x = 0; x < boardWidth; x++)
        {
            for (int y = 0; y < boardHeight; y++)
            {
                buttons[x][y].disable();
            }
        }
    }

    public int getFlagCount()
    {
        return flagCount;
    }

    public int getMineCount()
    {
        return mineCount;
    }

    public void incrementFlagCount()
    {
        flagCount++;
        statusBar.update();
    }

    public void decrementFlagCount()
    {
        flagCount--;
        statusBar.update();
    }

    void decrementSafeCount()
    {
        safeCount--;
        statusBar.update();
        if (safeCount == 0)
        {
            winGame();
        }
    }

    void loseGame()
    {
        disableButtons();
        showMines();
        windowManager.loseGame();
        initializeBoard(difficulty);
    }

    private void winGame()
    {
        disableButtons();
        showMines();
        flagCount = mineCount;
        windowManager.winGame();
    }

    private void showMines()
    {
        for(int x = 0; x < boardWidth; x++)
        {
            for (int y = 0; y < boardHeight; y++)
            {
                buttons[x][y].showIfMine();
            }
        }
    }

    boolean isStartOfGame()
    {
        return startOfGame;
    }

    int getButtonWidth()
    {
        return BUTTON_WIDTH;
    }

    int getButtonHeight()
    {
        return BUTTON_HEIGHT;
    }

    int getPanelWidth()
    {
        return BUTTON_WIDTH * boardWidth;
    }

    int getPanelHeight()
    {
        return BUTTON_HEIGHT * boardHeight;
    }

    void updateSize()
    {
        setSize(getPanelWidth(), getPanelHeight());
    }

    DIFFICULTY getDifficulty()
    {
        return difficulty;
    }

    void setDifficulty(DIFFICULTY difficulty)
    {
        this.difficulty = difficulty;
    }
}
