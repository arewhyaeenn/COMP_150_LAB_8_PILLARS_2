package MineSweeper;

public class MineSweeperClient
{
    public static void main(String[] args)
    {
        new WindowManager();
    }
}
