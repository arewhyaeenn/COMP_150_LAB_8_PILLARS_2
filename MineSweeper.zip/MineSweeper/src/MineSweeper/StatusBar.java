package MineSweeper;

import javax.swing.*;
import java.awt.*;

public class StatusBar extends JPanel
{
    final private static String DANGER_PREFIX = BoardButton.MINE_TEXT + " ";
    final private static String PLAY_STATUS_TEXT = "\u2603"; // bored snowman
    final private static String LOSE_STATUS_TEXT = "\u26a0"; // triangle with !
    final private static String WIN_STATUS_TEXT = "\u263b"; // smiley face
    final private static String BEGINNER_DIFFICULTY_TEXT = "BEGINNER";
    final private static String INTERMEDIATE_DIFFICULTY_TEXT = "INTERMEDIATE";
    final private static String EXPERT_DIFFICULTY_TEXT = "EXPERT";

    final private static int PANEL_HEIGHT = 30;
    final private static int SIDE_LABEL_WIDTH = 100;

    private BoardManager boardManager;

    private JLabel difficultyLabel;
    private JLabel statusLabel;
    private JLabel dangerLabel;

    enum STATUS
    {
        PLAY,
        WIN,
        LOSE
    }

    StatusBar(BoardManager boardManager)
    {
        super();

        this.boardManager = boardManager;

        setLayout(new BorderLayout());
        updatePanelSize();

        difficultyLabel = new JLabel();
        statusLabel = new JLabel();
        dangerLabel = new JLabel();

        difficultyLabel.setSize(SIDE_LABEL_WIDTH, getHeight());
        dangerLabel.setSize(SIDE_LABEL_WIDTH, getHeight());

        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);

        add(difficultyLabel, BorderLayout.WEST);
        add(statusLabel, BorderLayout.CENTER);
        add(dangerLabel, BorderLayout.EAST);

        boardManager.setStatusBar(this);
    }

    void update()
    {
        updateDangerText();
    }

    void update(STATUS status)
    {
        setStatus(status);
        updateDangerText();
    }

    void update(BoardManager.DIFFICULTY difficulty)
    {
        setDifficulty(difficulty);
        updateDangerText();
    }

    void update(STATUS status, BoardManager.DIFFICULTY difficulty)
    {
        setStatus(status);
        setDifficulty(difficulty);
        updateDangerText();
    }

    private void setStatus(STATUS status)
    {
        switch (status)
        {
            case WIN:
                statusLabel.setText(WIN_STATUS_TEXT);
                break;
            case LOSE:
                statusLabel.setText(LOSE_STATUS_TEXT);
                break;
            case PLAY:
                statusLabel.setText(PLAY_STATUS_TEXT);
                break;
        }
    }

    private void setDifficulty(BoardManager.DIFFICULTY difficulty)
    {
        switch (difficulty)
        {
            case BEGINNER:
                difficultyLabel.setText(BEGINNER_DIFFICULTY_TEXT);
                break;
            case INTERMEDIATE:
                difficultyLabel.setText(INTERMEDIATE_DIFFICULTY_TEXT);
                break;
            case EXPERT:
                difficultyLabel.setText(EXPERT_DIFFICULTY_TEXT);
                break;
        }
    }

    private void updateDangerText()
    {
        int unflaggedCount = boardManager.getMineCount() - boardManager.getFlagCount();
        dangerLabel.setText(DANGER_PREFIX + unflaggedCount);
    }

    void reset()
    {
        update(STATUS.PLAY, boardManager.getDifficulty());
    }

    private void updatePanelSize()
    {
        setSize(getWidth(), getHeight());
    }

    @Override
    public int getHeight()
    {
        return PANEL_HEIGHT;
    }

    @Override
    public int getWidth()
    {
        return boardManager.getPanelWidth();
    }

    void updateSize()
    {
        setSize(getWidth(), getHeight());
    }
}
