package MineSweeper;

import javax.swing.*;
import java.awt.*;

public class WindowManager extends JFrame
{
    private static final String WINDOW_TITLE = "Minesweeper";

    private BoardManager boardManager;
    private StatusBar statusBar;
    private MenuBar menuBar;

    private Container contentPane;

    WindowManager()
    {
        super(WINDOW_TITLE);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new BorderLayout());

        boardManager = new BoardManager(this);
        statusBar = new StatusBar(boardManager);
        menuBar = new MenuBar(this);

        contentPane = getContentPane();
        contentPane.add(menuBar, BorderLayout.NORTH);
        contentPane.add(statusBar, BorderLayout.SOUTH);
        contentPane.add(boardManager, BorderLayout.CENTER);

        updateSize();
        setResizable(false);
        setVisible(true);

        initializeGame();
    }

    void updateSize()
    {
        boardManager.updateSize();
        statusBar.updateSize();
        menuBar.updateSize();
        setSize(boardManager.getPanelWidth(),
                 boardManager.getPanelHeight() +
                        statusBar.getHeight() +
                        menuBar.getHeight()
        );
    }

    public void winGame()
    {
        statusBar.update(StatusBar.STATUS.WIN);
        JOptionPane.showMessageDialog(this,"YOU WIN C=");
        initializeGame();
    }

    public void loseGame()
    {
        statusBar.update(StatusBar.STATUS.LOSE);
        JOptionPane.showMessageDialog(this,"YOU LOSE DX");
        initializeGame();
    }

    void initializeGame()
    {
        boardManager.initializeBoard();
        updateSize();
        statusBar.update(StatusBar.STATUS.PLAY, boardManager.getDifficulty());
    }

    void initializeGame(BoardManager.DIFFICULTY difficulty)
    {
        boardManager.setDifficulty(difficulty);
        initializeGame();
    }
}
