package MineSweeper;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class MenuBar extends JPanel
{
    final private static String BEGINNER_STRING = "Beginner";
    final private static String INTERMEDIATE_STRING = "Intermediate";
    final private static String EXPERT_STRING = "Expert";

    final private static int BAR_HEIGHT = 20;
    WindowManager windowManager;

    private JMenuBar menuBar;
    private JMenu gameMenu;
    private JMenu helpMenu;

    MenuBar(WindowManager windowManager)
    {
        super();
        this.windowManager = windowManager;

        setSize(windowManager.getWidth(), getHeight());
        setLayout(new BorderLayout());

        menuBar = new JMenuBar();

        setupGameMenu();
        setupHelpMenu();

        add(menuBar, BorderLayout.CENTER);
        setVisible(true);
    }

    private void setupGameMenu()
    {
        gameMenu = new JMenu("GAME");

        JMenuItem newGameItem = new JMenuItem("New Game");
        newGameItem.addActionListener(this::startNewGame);
        gameMenu.add(newGameItem);

        JMenu difficultyMenu = new JMenu("Difficulty");

        JMenuItem beginnerItem = new JMenuItem(BEGINNER_STRING);
        beginnerItem.addActionListener(event -> changeDifficulty(beginnerItem.getText()));
        difficultyMenu.add(beginnerItem);

        JMenuItem intermediateItem = new JMenuItem(INTERMEDIATE_STRING);
        intermediateItem.addActionListener(event -> changeDifficulty(intermediateItem.getText()));
        difficultyMenu.add(intermediateItem);

        JMenuItem expertItem = new JMenuItem(EXPERT_STRING);
        expertItem.addActionListener(event -> changeDifficulty(expertItem.getText()));
        difficultyMenu.add(expertItem);

        gameMenu.add(difficultyMenu);

        menuBar.add(gameMenu);
    }

    private void setupHelpMenu()
    {
        helpMenu = new JMenu("HELP");
        helpMenu.add(new JLabel("Ugh just google \"Minesweeper\" please..."));
        menuBar.add(helpMenu);
    }

    private void startNewGame(ActionEvent event)
    {
        windowManager.initializeGame();
    }

    private void changeDifficulty(String difficultyString)
    {
        BoardManager.DIFFICULTY difficulty;
        switch (difficultyString)
        {
            case BEGINNER_STRING:
                difficulty = BoardManager.DIFFICULTY.BEGINNER;
                break;
            case INTERMEDIATE_STRING:
                difficulty = BoardManager.DIFFICULTY.INTERMEDIATE;
                break;
            case EXPERT_STRING:
                difficulty = BoardManager.DIFFICULTY.EXPERT;
                break;
            default:
                difficulty = BoardManager.DIFFICULTY.BEGINNER;
                System.out.println("How on earth did we get here???");
        }
        windowManager.initializeGame(difficulty);
    }

    @Override
    public int getHeight()
    {
        return BAR_HEIGHT;
    }

    void updateSize()
    {
        setSize(getWidth(), getHeight());
    }
}
