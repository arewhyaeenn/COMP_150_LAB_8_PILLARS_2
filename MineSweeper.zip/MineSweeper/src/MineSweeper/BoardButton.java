package MineSweeper;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class BoardButton extends JButton
{
    final static String MINE_TEXT = "\u2739"; // 16 pointed star
    final private static String EMPTY_TEXT = " ";
    final static String FLAGGED_TEXT = "\u2691"; // thicccc x
    final private static String UNKNOWN_TEXT = "?";

    private BoardManager boardManager;
    private int xIndex, yIndex;

    private boolean containsMine = false;
    private int adjacentMineCount = 0;

    enum BUTTON_STATE
    {
        CLICKABLE,
        CLICKED,
        FLAGGED,
        UNKNOWN,
        DISABLED
    }
    private BUTTON_STATE state;

    BoardButton(BoardManager boardManager, int x, int y)
    {
        super();

        this.boardManager = boardManager;
        this.xIndex = x;
        this.yIndex = y;

        setState(BUTTON_STATE.CLICKABLE);

        setupActionListeners();
        setupAesthetics(boardManager.getButtonWidth(), boardManager.getButtonHeight());
    }

    void placeMine()
    {
        this.containsMine = true;
        boardManager.incrementAdjacentMines(xIndex, yIndex);
    }

    void incrementAdjacentMines()
    {
        adjacentMineCount++;
    }

    public void setupAesthetics(int width, int height)
    {
        setText(EMPTY_TEXT);
        setMargin(new Insets(0,0,0,0));
        setSize(new Dimension(width, height));
        setBorder(BorderFactory.createLineBorder(Color.black));
        setOpaque(true);
    }

    private void setupActionListeners()
    {
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent event) {
                onClick(event);
            }
        });
    }

    private void onClick(MouseEvent event)
    {
        switch(event.getButton())
        {
            case MouseEvent.BUTTON1:
                if (event.isControlDown())
                    onRightClick();
                else
                    onLeftClick();
                break;
            case MouseEvent.BUTTON3:
                onRightClick();
                break;
            default:
                System.out.println("What button was that..." + event.getButton());
        }
    }

    private void onLeftClick()
    {
        if (boardManager.isStartOfGame())
        {
            boardManager.placeMines(xIndex, yIndex);
        }
        if (state == BUTTON_STATE.CLICKABLE)
        {
            setState(BUTTON_STATE.CLICKED);
        }
    }

    private void onRightClick()
    {
        switch (state)
        {
            case CLICKABLE:
                setState(BUTTON_STATE.FLAGGED);
                break;
            case FLAGGED:
                setState(BUTTON_STATE.UNKNOWN);
                break;
            case UNKNOWN:
                setState(BUTTON_STATE.CLICKABLE);
                break;
            case CLICKED:
                break;
            case DISABLED:
                break;
        }
    }

    private void setState(BUTTON_STATE newState)
    {
        switch (newState)
        {
            case CLICKABLE:
                setText(EMPTY_TEXT);
                state = newState;
                break;
            case FLAGGED:
                setText(FLAGGED_TEXT);
                boardManager.incrementFlagCount();
                state = newState;
                break;
            case UNKNOWN:
                setText(UNKNOWN_TEXT);
                boardManager.decrementFlagCount();
                state = newState;
                break;
            case CLICKED:
                setClicked();
                break;
            case DISABLED:
                break;
        }
    }

    public void setClicked()
    {
        if (state != BUTTON_STATE.CLICKED)
        {
            state = BUTTON_STATE.CLICKED;
            setBackground(Color.GRAY);
            setBorderPainted(false);
            if (containsMine)
            {
                setText(MINE_TEXT);
                loseGame();
            }
            else
            {
                if (adjacentMineCount > 0)
                {
                    setText("" + adjacentMineCount);
                }
                else
                {
                    setText(EMPTY_TEXT);
                    clearAdjacent();
                }
                boardManager.decrementSafeCount();
            }
        }
    }

    private void loseGame()
    {
        boardManager.loseGame();
    }

    private void clearAdjacent()
    {
        boardManager.clearAdjacent(xIndex, yIndex);
    }

    public void showIfMine()
    {
        if (containsMine)
        {
            setText(MINE_TEXT);
        }
    }

    @Override
    public void disable()
    {
        setState(BUTTON_STATE.DISABLED);
    }
}
