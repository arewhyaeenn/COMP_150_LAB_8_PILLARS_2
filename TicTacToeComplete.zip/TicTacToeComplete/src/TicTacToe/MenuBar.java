package TicTacToe;

import javax.swing.*;
import java.awt.*;

/**
 * The MenuBar will contain dropdown menus.
 * It will include utilities to start a new game,
 * as well as a help menu for users who don't know how
 * to play TicTacToe. It will also allow the user
 * to reset the scoreboard so each player has 0 wins
 * (by calling the corresponding method in the StatusBar),
 * or to quit the game.
 */

public class MenuBar extends JPanel
{
    final private static int BAR_HEIGHT = 20;
    private WindowManager windowManager;
    private StatusBar statusBar;

    private JMenuBar menuBar;

    MenuBar(WindowManager windowManager)
    {
        super();
        this.windowManager = windowManager;
        this.statusBar = windowManager.getStatusBar();

        setSize(windowManager.getWidth(), getHeight());
        setLayout(new BorderLayout());

        menuBar = new JMenuBar();

        setupGameMenu();
        setupHelpMenu();

        add(menuBar, BorderLayout.CENTER);
        setVisible(true);
    }


    /**
     * Constructs the "GAME" dropdown menu.
     * This dropdown menu will consist of items allowing the user to
     * start a new game (ending the current game without a winner)
     * and to reset the scoreboard.
     */
    private void setupGameMenu()
    {
        JMenuItem gameMenu = new JMenu("GAME");

        JMenuItem newGameItem = new JMenuItem("New Game");
        newGameItem.addActionListener(event -> startNewGame());
        gameMenu.add(newGameItem);

        JMenuItem resetScoreboardItem = new JMenuItem("Reset Scoreboard");
        resetScoreboardItem.addActionListener(event -> statusBar.resetScores());
        gameMenu.add(resetScoreboardItem);

        JMenuItem quitItem = new JMenuItem("Quit");
        quitItem.addActionListener(event->windowManager.dispose());
        gameMenu.add(quitItem);

        menuBar.add(gameMenu);
    }


    /**
     * Constructs the "HELP" menu, which incredulously asks if the
     * user really needs help.
     */
    private void setupHelpMenu()
    {
        JMenuItem helpMenu = new JMenu("HELP");
        helpMenu.add(new JLabel("Wait really?"));
        menuBar.add(helpMenu);
    }


    /**
     * Starts a new game without finishing the current game.
     * Does so through the appropriate method in the WindowManager class.
     */
    private void startNewGame()
    {
        windowManager.initializeGame();
    }


    /* ACCESSORS AND MUTATORS FOR DISPLAY SIZE */
    @Override
    public int getHeight()
    {
        return BAR_HEIGHT;
    }

    void updateSize()
    {
        setSize(getWidth(), getHeight());
    }
}
