package TicTacToe;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

/**
 * The BoardManager class will manage the 3x3 grid of buttons necessary
 * for a TicTacToe game. It will also track which players turn it is,
 * and check after each turn if the game is over (and if so, who won).
 *
 * It will call methods from the StatusBar whenever changes in the gamestate
 * occur to ensure the StatusBar stays up to date.
 */

public class BoardManager extends JPanel
{
    private StatusBar statusBar;

    private BoardButton[][] buttons;

    // width and height of board grid (number of buttons)
    final private int BOARD_WIDTH = 3;
    final private int BOARD_HEIGHT = 3;

    // width and height of buttons in pixels
    private static final int BUTTON_WIDTH = 100;
    private static final int BUTTON_HEIGHT = 100;

    // enumerator listing whose turn it might be
    public enum TURN_STATE
    {
        X, O, NONE
    }

    // trackers for current players turn and number of turns passed in a game
    private TURN_STATE turn;
    private int turnCount;

    BoardManager()
    {
        super();
        setBackground(Color.GRAY);
    }

    /**
     * Sets all variables up for the start of a game as follows:
     * Sets the turnCount to 0.
     * Randomly chooses a starting player (sets turn to TURN_STATE.X or TURN_STATE.O).
     * Calls the statusBar's updateTurn method to reflect whose turn it is.
     * Calls the layoutButtons method to set up the 3x3 grid for a new game.
     */
    void initialize()
    {
        turnCount = 0;
        Random generator = new Random();
        switch (generator.nextInt(2))
        {
            case 0:
                turn = TURN_STATE.X;
                break;
            case 1:
                turn = TURN_STATE.O;
                break;
        }
        statusBar.updateTurn();
        layoutButtons();
    }


    /**
     * Sets up the 3x3 grid of buttons for a new game as follows:
     *
     * (DONE)
     * Removes all components from this object (note that BoardManager extends JPanel, check the JPanel documentation).
     * Sets this objects Layout to a new GridLayout with the necessary number of rows and columns.
     * Update this objects size.
     *
     * (TODO)
     * Initializes the buttons array to be a 3x3 array of BoardButtons.
     *      (Don't use magic numbers, use BOARD_WIDTH and BOARD_HEIGHT instead of 3s)
     * Loops through the indexes in the buttons array (row by row) calling the addButton method at each x, y coordinate.
     *
     * (DONE)
     * Revalidates and repaints this object.
     */
    private void layoutButtons()
    {
        removeAll();
        setLayout( new GridLayout(BOARD_HEIGHT, BOARD_WIDTH) );
        setSize(getPanelWidth(), getPanelHeight());

        buttons = new BoardButton[BOARD_WIDTH][BOARD_HEIGHT];
        for (int y = 0; y < BOARD_HEIGHT; y++)
        {
            for (int x = 0; x < BOARD_WIDTH; x++)
            {
                addButton(x, y);
            }
        }

        revalidate();
        repaint();
    }

    void setStatusBar(StatusBar statusBar)
    {
        this.statusBar = statusBar;
    }


    /**
     * Creates a new BoardButton; passes in itself and the buttons x and y coordinates.
     * Adds the button to this JPanel's contents using the JPanel's add method.
     * Assigns a reference to the new BoardButton to the buttons array at the appropriate index.
     *
     * @param x the x coordinate of the new button
     * @param y the y coordinate of the new button
     */
    private void addButton(int x, int y)
    {
        BoardButton button = new BoardButton(this, x, y);
        add(button);
        this.buttons[x][y] = button;
    }


    public TURN_STATE getTurn()
    {
        return turn;
    }


    /**
     * Checks if the last move caused someone to win the game.
     * If so, ends the game (with the player whose turn it currently is
     * as the winner. (Check out the endGame method).
     *
     * If nobody won the game, iterate the turnCount variable, then check
     * if the board is full by using the turnCount variable (there can
     * only be 9 turns in a game). If the game is over without a winner,
     * call the endGame method with TURN_STATE.NONE as an argument, to
     * end the game as a tie.
     *
     * If the game isn't over (i.e. the game didn't end above)
     * switch which players turn it is and call an appropriate method in
     * the statusBar to update it accordingly.
     *
     * @param x the x coordinate of the last move
     * @param y the y coordinate of the last move
     */
    public void endTurn(int x, int y)
    {
        if (checkForWinner(x, y))
        {
            endGame(turn);
        }
        else if (turnCount > 7)
        {
            endGame(TURN_STATE.NONE);
        }
        else
        {
            turnCount++;
            switch (turn)
            {
                case O:
                    turn = TURN_STATE.X;
                    break;
                case X:
                    turn = TURN_STATE.O;
                    break;
            }
            statusBar.updateTurn();
        }
    }


    /**
     * Checks if there is a win involving the button at the specified
     * x and y indexes on the board.
     * @param xIndex
     * @param yIndex
     * @return true if someone won, false otherwise.
     */
    private boolean checkForWinner(int xIndex, int yIndex)
    {
        boolean winner = checkColumnForWinner(xIndex);
        if (!winner) winner = checkRowForWinner(yIndex);
        if (!winner) winner = checkDiagonalsForWinner(xIndex, yIndex);
        return winner;
    }


    /**
     * Checks if the column with the specified x index
     * contains either all X's or all O's to check if there
     * is a winner. Check out the BoardButton class's getState method.
     *
     * @param xIndex the xIndex of the row to be checked.
     * @return true if the column is all X's or all O's, false otherwise.
     */
    private boolean checkColumnForWinner(int xIndex)
    {
        boolean winner = true;
        BoardButton.BUTTON_STATE state = buttons[xIndex][0].getState();

        if (state == BoardButton.BUTTON_STATE.EMPTY)
        {
            return false;
        }

        for (int yIndex = 1; yIndex < 3 && winner; yIndex++)
        {
            winner = state == buttons[xIndex][yIndex].getState();
        }
        return winner;
    }


    /**
     * Checks if the row with the specified y index
     * contains either all X's or all O's to check if there
     * is a winner. Check out the BoardButton class's getState method.
     *
     * @param yIndex
     * @return true if the row is all X's or all O's, false otherwise.
     */
    private boolean checkRowForWinner(int yIndex)
    {
        boolean winner = true;
        BoardButton.BUTTON_STATE state = buttons[0][yIndex].getState();

        if (state == BoardButton.BUTTON_STATE.EMPTY)
        {
            return false;
        }

        for (int xIndex = 1; xIndex < 3 && winner; xIndex++)
        {
            winner = state == buttons[xIndex][yIndex].getState();
        }
        return winner;
    }


    /**
     * If the specified x-y index is on the top-left to bottom-right
     * diagonal, checks if said diagonal is all X's or all O's and
     * returns true if it is.
     *
     * If the specified x-y index is on the top-right to bottom-left
     * diagonal, checks if said diagonal is all X's or all O's and
     * returns true if it is.
     *
     * Returns false if neither of the previous checks returned true.
     *
     * @param xIndex the x coordinate of the spot being checked for diagonal wins
     * @param yIndex the y coordinate of the spot being checked for diagonal wins
     * @return true if the button at the specified x-y index is part of
     * a win on a diagonal of the board, false otherwise.
     */
    private boolean checkDiagonalsForWinner(int xIndex, int yIndex)
    {
        boolean winner = false;
        // top left to bottom right
        if (xIndex == yIndex)
        {
            BoardButton.BUTTON_STATE state = buttons[0][0].getState();
            boolean flag = state != BoardButton.BUTTON_STATE.EMPTY;
            for (int index = 1; index < 3 && flag; index++)
            {
                if (buttons[index][index].getState() != state)
                {
                    flag = false;
                }
            }
            winner = flag;
        }

        if (!winner && xIndex + yIndex == 2)
        {
            BoardButton.BUTTON_STATE state = buttons[0][2].getState();
            boolean flag = state != BoardButton.BUTTON_STATE.EMPTY;
            for (int index = 1; index < 3 && flag; index++)
            {
                if (buttons[index][2-index].getState() != state)
                {
                    flag = false;
                }
            }
            winner = flag;
        }

        return winner;
    }


    /**
     * Ends the game with the specified winner as follows:
     *
     * Disables all buttons with the disableButtons method.
     * If X or O won, increments the score with the statusBar's addPoint method.
     * Creates a message dialog stating that X won, O won or that there was a tie.
     * Calls the initialize method, to reset the board for the next game.
     *
     * @param winner the player that just won the game (NONE if it's a tie)
     */
    void endGame(TURN_STATE winner)
    {
        disableButtons();
        switch (winner)
        {
            case X:
                statusBar.addPoint(winner);
                JOptionPane.showMessageDialog(this,"X WINS!");
                break;
            case O:
                statusBar.addPoint(winner);
                JOptionPane.showMessageDialog(this, "O WINS!");
                break;
            case NONE:
                JOptionPane.showMessageDialog(this, "TIE GAME!");
                break;
        }
        initialize();
    }


    /**
     * Iterates through the buttons array, calling each BoardButton's disable method.
     * This method is for use at when a game ends, to disable all buttons until the
     * next game starts.
     */
    private void disableButtons()
    {
        for (int x = 0; x < BOARD_WIDTH; x++)
        {
            for (int y = 0; y < BOARD_HEIGHT; y++)
            {
                buttons[x][y].disable();
            }
        }
    }


    /* ACCESSORS AND MUTATORS FOR SIZE */
    int getButtonWidth()
    {
        return BUTTON_WIDTH;
    }

    int getButtonHeight()
    {
        return BUTTON_HEIGHT;
    }

    int getPanelWidth()
    {
        return BUTTON_WIDTH * BOARD_WIDTH;
    }

    int getPanelHeight()
    {
        return BUTTON_HEIGHT * BOARD_HEIGHT;
    }

    void updateSize()
    {
        setSize(getPanelWidth(), getPanelHeight());
    }
}
