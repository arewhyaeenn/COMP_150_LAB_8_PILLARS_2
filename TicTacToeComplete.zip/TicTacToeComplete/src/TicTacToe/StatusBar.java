package TicTacToe;

import javax.swing.*;
import java.awt.*;

/**
 * The StatusBar will display gamestate information for players.
 * It will include which player's turn it is and how many wins
 * each player has.
 */

public class StatusBar extends JPanel
{
    final private static String TURN_POSTFIX = "'s Turn ";
    final private static String X_TEXT = "X";
    final private static String O_TEXT = "O";

    final private static int PANEL_HEIGHT = 30;
    final private static int SIDE_LABEL_WIDTH = 100;

    // the BoardManager running the games for which this StatusBar is displaying information
    private BoardManager boardManager;

    // labels for whose turbn it is, and how many wins each player has
    private JLabel turnLabel;
    private JLabel xWinLabel;
    private JLabel oWinLabel;

    // counters for the number of wins each player has
    private int xWins;
    private int oWins;

    StatusBar(BoardManager boardManager)
    {
        super();

        this.boardManager = boardManager;

        setLayout(new BorderLayout());
        updatePanelSize();

        turnLabel = new JLabel();
        xWinLabel = new JLabel();
        oWinLabel = new JLabel();

        xWinLabel.setSize(SIDE_LABEL_WIDTH, getHeight());
        oWinLabel.setSize(SIDE_LABEL_WIDTH, getHeight());

        turnLabel.setHorizontalAlignment(SwingConstants.CENTER);

        add(xWinLabel, BorderLayout.WEST);
        add(turnLabel, BorderLayout.CENTER);
        add(oWinLabel, BorderLayout.EAST);

        boardManager.setStatusBar(this);
        updateScoreboard();
    }


    /**
     * Updates the displayed turn to match whose turn it is according
     * to the BoardManager.
     */
    public void updateTurn()
    {
        switch(boardManager.getTurn())
        {
            case X:
                turnLabel.setText(X_TEXT + TURN_POSTFIX);
                break;
            case O:
                turnLabel.setText(O_TEXT + TURN_POSTFIX);
                break;
        }
    }


    /**
     * Updates the xWinLabel and yWinLabel JLabels to reflect the current
     * number of wins for each player.
     */
    public void updateScoreboard()
    {
        xWinLabel.setText(X_TEXT + " : " + xWins);
        oWinLabel.setText(O_TEXT + " : " + oWins);
    }


    /**
     * Adds a point to the specified player, and updates
     * the corresponding JLabel (xWinLabel or oWinLabel).
     * @param winner the player who just won a game
     */
    public void addPoint(BoardManager.TURN_STATE winner)
    {
        switch(winner)
        {
            case X:
                xWins++;
                xWinLabel.setText(X_TEXT + " : " + xWins);
                break;
            case O:
                oWins++;
                oWinLabel.setText(O_TEXT + " : " + oWins);
        }
    }


    /**
     * Sets both players scores to 0, updates the scoreboard
     * to reflect new scores.
     */
    void resetScores()
    {
        xWins = 0;
        oWins = 0;
        updateScoreboard();
    }


    /* ACCESSORS AND MUTATORS FOR SIZE OF DISPLAY */
    private void updatePanelSize()
    {
        setSize(getWidth(), getHeight());
    }

    @Override
    public int getHeight()
    {
        return PANEL_HEIGHT;
    }

    @Override
    public int getWidth()
    {
        return boardManager.getPanelWidth();
    }

    void updateSize()
    {
        setSize(getWidth(), getHeight());
    }
}

