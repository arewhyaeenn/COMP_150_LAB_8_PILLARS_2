package TicTacToe;

import javax.swing.*;
import java.awt.*;

/**
 * The WindowManager will serve as the uppermost level of the
 * game. It will control the window size (and tell other components
 * when to update their size). It will also run game initializations,
 * by resizing all elements and then telling other elements to run
 * their contained methods to start new games.
 */

public class WindowManager extends JFrame
{
    private static final String WINDOW_TITLE = "TicTacToe";

    private BoardManager boardManager;
    private StatusBar statusBar;
    private MenuBar menuBar;

    WindowManager()
    {
        super(WINDOW_TITLE);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new BorderLayout());

        boardManager = new BoardManager();
        statusBar = new StatusBar(boardManager);
        menuBar = new MenuBar(this);

        Container contentPane = getContentPane();
        contentPane.add(menuBar, BorderLayout.NORTH);
        contentPane.add(statusBar, BorderLayout.SOUTH);
        contentPane.add(boardManager, BorderLayout.CENTER);

        updateSize();
        setResizable(false);
        setVisible(true);

        initializeGame();
    }


    /**
     * Starts a new game.
     * Updates the boardManager using the appropriate BoardManager method.
     * Updates the statusBar using the appropriate StatusBar method.
     */
    void initializeGame()
    {
        boardManager.initialize();
        updateSize();
        statusBar.updateTurn();
    }


    /**
     * Accessor for the statusBar.
     * @return the statusBar...
     */
    public StatusBar getStatusBar()
    {
        return statusBar;
    }


    /* MUTATOR TO RESIZE ALL ELEMENTS */
    // This method is a bit redundant here. It will not be redundant in
    // future projects where the size of the window changes.
    void updateSize()
    {
        boardManager.updateSize();
        statusBar.updateSize();
        menuBar.updateSize();
        setSize(boardManager.getPanelWidth(),
                boardManager.getPanelHeight() +
                        statusBar.getHeight() +
                        menuBar.getHeight()
        );
    }
}
